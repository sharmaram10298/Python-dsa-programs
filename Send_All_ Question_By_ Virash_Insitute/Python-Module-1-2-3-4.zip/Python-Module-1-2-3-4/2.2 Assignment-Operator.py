"""
Assignment Operator
+=,-=,*=,/=,%=,//=(floor division),**=(exponent)

eg.

x=3
x=x+5 => x+=5

x-=4 => x=x-4
"""

x=3
x+=4
print("X =",x)
