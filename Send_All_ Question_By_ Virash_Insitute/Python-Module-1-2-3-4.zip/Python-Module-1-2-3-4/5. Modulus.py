a=eval(input("Enter 1st Number : "))
b=eval(input("Enter 2nd Number : "))
print(eval("a%b"))
