count = 0
while (count < 1):    
    count = count+1
    print(count)
    break
else:
    print("No Break")
