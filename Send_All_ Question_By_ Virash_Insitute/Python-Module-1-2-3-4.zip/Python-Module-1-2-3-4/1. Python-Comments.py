#single line comment  
print ("Hello Python")  
"""This is 
multiline comment"""

input("press any key to exit")
